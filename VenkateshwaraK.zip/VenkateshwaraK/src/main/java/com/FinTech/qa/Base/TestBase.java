package com.FinTech.qa.Base;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

import com.FinTech.qa.Util.Testutil;

public class TestBase {

	public static WebDriver driver;
	public static Properties prop;
	 protected static String basePath = System.getProperty("user.dir");
	public TestBase() throws IOException {
		prop = new Properties();
		FileInputStream ip = new FileInputStream(
				basePath+"/src/main/java/com/FinTech"
						+ "/qa/config/config.properties");
		prop.load(ip);

	}

	public static void initialization() {
		String browserName = prop.getProperty("browser");
		if (browserName.equals("chrome")) {
			io.github.bonigarcia.wdm.WebDriverManager.chromedriver().setup();
			driver = new HtmlUnitDriver();
			//driver = new ChromeDriver();

		}

		else if (browserName.equals("FireFox")) {
			io.github.bonigarcia.wdm.WebDriverManager.firefoxdriver().setup();
			driver = new HtmlUnitDriver();
			// driver = new FirefoxDriver();
		}

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(Testutil.Page_Load_Timeout, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(Testutil.Implicit_Wait, TimeUnit.SECONDS);

		driver.get(prop.getProperty("url"));
	}

}
