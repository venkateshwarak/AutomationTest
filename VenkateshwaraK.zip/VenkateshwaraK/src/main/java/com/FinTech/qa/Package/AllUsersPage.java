package com.FinTech.qa.Package;

import java.io.IOException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.FinTech.qa.Base.TestBase;

public class AllUsersPage extends TestBase{

	
	

	@FindBy(xpath="//table[@id='users']/tbody/tr //td[1]")
	WebElement verifyUserName;
	
	@FindBy(xpath="//a[contains(text(),'New User')]")
	WebElement NewUserButton;
	public AllUsersPage() throws IOException {
		PageFactory.initElements(driver, this);
	}
	
	public String VerifyAllUserPage() {
		return driver.getTitle();
			}
	
	public String VerifyCreatedUser() {
		 return verifyUserName.getText();
	}
	
	public void ClickNewUser() {
		NewUserButton.click();
	
		
	}

}
