package com.FinTech.qa.Package;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.FinTech.qa.Base.TestBase;

public class NewUserCreation extends TestBase {


	// Page Factory = OR
	@FindBy(name = "user.name")
	WebElement Name;

	@FindBy(xpath = "//input[@id='email']")
	WebElement Email;

	@FindBy(xpath = "//input[@id='password']")
	WebElement Password;

	@FindBy(name = "confirmationPassword")
	WebElement CnfPassword;
	
	@FindBy(id="user.name.error")
	
	WebElement User_Error;
	
	@FindBy(id="user.email.error")
	WebElement Email_Error;
	
	
	@FindBy(id="user.confirmationPassword.error")
	WebElement CnfPwd_Error;
	
	@FindBy(xpath="//Button[@type='submit']")
	WebElement Submit;
	
	@FindBy(xpath="//a[contains(text(),'All User')]")
	
	WebElement AllUser;
	// Initializing the Page Objects

	public  NewUserCreation() throws IOException {
		// super();
		PageFactory.initElements(driver, this);

	}

	// Actions
	public String  ValidateRegistrationPageTitle() {
		return driver.getTitle();
	}

	public  void CreatUser(String name, String email, String pwd, String cpwd){
		Name.sendKeys(name);
		Email.sendKeys(email);
		Password.sendKeys(pwd);
		CnfPassword.sendKeys(cpwd);
		Submit.click();
	
	
		}
	public WebElement DuplicateUser() {
		WebElement webElement = User_Error;
		return webElement;
	}
	
	public WebElement DuplicateEmail() {
		WebElement webElement = Email_Error;
		return webElement;
	}
	
	public WebElement ConfirmPwdNotMatch() {
		WebElement webElement = CnfPwd_Error;
		return webElement;
	}
	
	
	public void ClickAllUser() {
		AllUser.click();
	
		
	}
}
