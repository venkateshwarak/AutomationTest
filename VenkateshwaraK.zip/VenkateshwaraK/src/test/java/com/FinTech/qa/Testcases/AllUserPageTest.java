package com.FinTech.qa.Testcases;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.FinTech.qa.Base.TestBase;
import com.FinTech.qa.Package.AllUsersPage;
import com.FinTech.qa.Package.NewUserCreation;

public class AllUserPageTest extends TestBase {

	public AllUserPageTest() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	 AllUsersPage AllUser;
	NewUserCreation NewUser;

	@Before
	public  void Setup() throws IOException {

		System.out.println("In SetUp() ");
		try {
			initialization();
		} catch (Exception e) {
			System.out.println("Exception occured");
		}
		AllUser = new AllUsersPage();
		System.out.println("End SetUp() " + AllUser);
	}

	@Test
	public void AllUsersPage() {
		System.out.println("in AllUsersPage");
		NewUser.ClickAllUser();
	}
	@Test
	public void VerifyPageTitle() {
		System.out.println("In VerifyPageTitle() ");
		String title = AllUser.VerifyAllUserPage();
		Assert.assertEquals(title, "All User");
		System.out.println("End of VerifyPageTitle() ");

	}

	@Test
	public void verifyUser() {
		String UserName = AllUser.VerifyCreatedUser();
		Assert.assertEquals(UserName, "test1");
	}

}
