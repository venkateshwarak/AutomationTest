package com.FinTech.qa.Testcases;

import org.junit.Assert.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.FinTech.qa.Base.TestBase;
import com.FinTech.qa.Package.AllUsersPage;
import com.FinTech.qa.Package.NewUserCreation;
import com.FinTech.qa.Util.Testutil;
import com.google.common.collect.ObjectArrays;
import com.tngtech.java.junit.dataprovider.DataProvider;
import com.tngtech.java.junit.dataprovider.UseDataProvider;

//@RunWith(Parameterized.class)
//@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class NewUserTest extends TestBase {
	public NewUserTest() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}

	NewUserCreation NewUser = new NewUserCreation();
	static Testutil testUtil;
	AllUsersPage AllUser = new AllUsersPage();
	static Object[][] useDataInput;
	static final Logger log = Logger.getLogger(NewUserTest.class);

	@Before
	public void Setup() {
		System.out.println(log.getRootLogger());
		log.info("In SetUp() ...");
		try {
			initialization();
		} catch (Exception e) {
			System.out.println("Exception occured");
		}
		try {
			NewUser = new NewUserCreation();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Test()

	public void VerifyPageTitle() {
		// log.info("VerifyPageTitle is started");
		String title = NewUser.ValidateRegistrationPageTitle();
		Assert.assertEquals("Landing page is displayed", "New User", title);

	}

	public static Object[][] getData() {
		Object[][] data = testUtil.getTestData("UserData");
		useDataInput = data;
		return data;
	}

	@Test

	public void CreateNewUser() {
		// Boolean flag = false;
		try {
			useDataInput = getData();
			Integer rowCnt = useDataInput.length;
			for (int i = 0; i < rowCnt; i++) {
				NewUser.CreatUser(useDataInput[i][0].toString(), useDataInput[i][1].toString(),
						useDataInput[i][2].toString(), useDataInput[i][3].toString());

				try {
					if ((NewUser.DuplicateUser().isDisplayed())) {
						String errorDesc = NewUser.DuplicateUser().getText();
						Assert.assertEquals("Must be unique", errorDesc);
					} else if ((NewUser.DuplicateEmail().isDisplayed())) {
						String errorDesc = NewUser.DuplicateEmail().getText();
						Assert.assertEquals("Must be unique", errorDesc);
					} else if ((NewUser.ConfirmPwdNotMatch().isDisplayed())) {
						String errorDesc = NewUser.ConfirmPwdNotMatch().getText();
						Assert.assertEquals("passwords are not the same", errorDesc);
					}

					// NewUser.ClickAllUser();
					String PageTitle = driver.getTitle();
					if (PageTitle.equals("New User")) {
						Assert.assertEquals("User is already exists", "New User", PageTitle);
					} else {
						Assert.assertEquals("User is created Successfully", "All User", PageTitle);
					}

				} catch (Exception e) {
				}
				/*
				 * driver.manage().timeouts().implicitlyWait(Testutil.Page_Load_Timeout,
				 * TimeUnit.SECONDS); String User = AllUser.VerifyCreatedUser();
				 * System.out.println(User); Assert.assertEquals("All User", User);
				 */
				// driver.manage().timeouts().implicitlyWait(Testutil.Page_Load_Timeout,
				// TimeUnit.SECONDS);
				// AllUser.ClickNewUser();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@After
	public void tearDown() {
		driver.quit();
	}

}
